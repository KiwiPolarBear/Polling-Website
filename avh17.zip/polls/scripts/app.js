(function () {
    'use strict';

    /* App Module */

    var pollsApp = angular.module('pollsApp', [
      'appControllers'
    ]);
    
}())
